function toggleCategory(evt,num_categ) {
//	target=evt.getTarget().getParentNode()
//	categ = target.getAttribute("id")
//	this_categ = Number(categ.substring(5,categ.length))
	categ="categ"+num_categ
	this_categ=num_categ
	newvar = this_categ+1
	this_container=SVGDoc.getElementById("cc"+this_categ)
	categ_obj = SVGDoc.getElementById(categ)
	triangle = categ_obj.getElementsByTagName("path").item(0)
	if(catStatus[this_categ]==false) 
	{
//handle this category, including individual layers 
		this_container.getStyle().setProperty("visibility","visible")	
		triangle.setAttribute("style","stroke:yellow;fill:white;opacity:0.5");
		triangle.setAttribute("d","M2 "+(catVertGap+3)+" 2 "+(catFsize+catVertGap-1)+" 10 "+(catVertGap+7)+"z")
//shift categories below
		for(var k=newvar;k<cat_names.length;k++)
		{
			yCategory[k]= yCategory[k]+yCatsize[this_categ]
			contain = SVGDoc.getElementById("categ"+k)
			contain.setAttribute("transform","translate("+xoffset+","+yCategory[k]+")")
		}
		hierheight = hierheight+yCatsize[this_categ]
		catStatus[this_categ]=true
	}
	else
	{
//handle this category, including individual layers 
		this_container.getStyle().setProperty("visibility","hidden")	
		triangle.setAttribute("style","stroke:yellow;fill:yellow");
		triangle.setAttribute("d","M0 "+(catVertGap+4)+" 5 "+(catFsize+catVertGap-1)+" 10 "+(catVertGap+4)+"z")
//shift categories below
		for(var k=newvar;k<cat_names.length;k++)
		{
			yCategory[k]= yCategory[k]-yCatsize[this_categ]
			contain = SVGDoc.getElementById("categ"+k)
			contain.setAttribute("transform","translate("+xoffset+","+yCategory[k]+")")
		}
		hierheight = hierheight-yCatsize[this_categ]
		catStatus[this_categ]=false
	}
	aa = cat_names.length
//	hierheight = yCategory[aa-1]
	hierrect = SVGDoc.getElementById("hier_rect")
	hierrect.setAttribute("height",hierheight)
	currentNaviHeight = hierheight + 100
	sbSync()
}

function toggleLayer(evt)
{
	xaction="layershow"
	target=evt.getTarget().getParentNode()
	layer = target.getAttribute("id")
	currentlayer_type = layer.substring(0,3)
//	alert(currentlayer_type)
	unders=layer.indexOf("_")
	currentlayer_num = Number(layer.substring(3,unders))
//	alert(currentlayer_type+"  "+currentlayer_num)
//	num_cat = Number(layer.substring(3,unders))
//	num_lay = Number(layer.substring(unders+1,layer.length))
//	if (layerchk[num_cat][num_lay]==true)
	if(currentlayer_type=="poi") layertype = 3
	if(currentlayer_type=="lin") layertype = 2
	if(currentlayer_type=="reg") layertype = 1

//alert(layershow[layertype][currentlayer_num]+"    "+currentlayer_type+currentlayer_num+"_chk" +SVGDoc.getElementById(currentlayer_type+currentlayer_num+"_chk"))


	if (layershow[layertype][currentlayer_num]==2)
	{
//		alert(layer+"chk")
		
		checkmark = SVGDoc.getElementById(currentlayer_type+currentlayer_num+"_chk")
		par = checkmark.getParentNode()
		par.removeChild(checkmark)
//		layerchk[num_cat][num_lay]=false
		layershow[layertype][currentlayer_num]=1
		undrawLayer(layertype,currentlayer_num)
	}
	else
	{
//create checkmark		
//checkmark path
	path1 = SVGDoc.createElement("path")	
	path1.setAttribute("id",currentlayer_type+currentlayer_num+"_chk")
	path1.setAttribute("d","M2 5 5 8 9 2")
	path1.setAttribute("style","stroke-width:3;stroke:black;fill:none")
//	alert(layer+"cmark")
	g_target=SVGDoc.getElementById(currentlayer_type+currentlayer_num+"_cmark")
	g_target.appendChild(path1)

//		layerchk[num_cat][num_lay]=true
		layershow[layertype][currentlayer_num]=2
		drawLayer(layertype,currentlayer_num)
	}
}

function undrawLayer(layertype,currentlayer_num)
{
	layerID = currentlayer_type+currentlayer_num
	thislayer = SVGDoc.getElementById(layerID)
	thislayer.setAttribute("visibility", "hidden")
	
}
function drawLayer(layertype,currentlayer_num)
{
	layerID = currentlayer_type+currentlayer_num
	thislayer = SVGDoc.getElementById(layerID)
	if(!thislayer)
    	switch(layertype)       
    	{
			case 1: xmessagenumber=125;load_layer();break;
			case 2: xmessagenumber=124;load_layer();break;
			case 3: xmessagenumber=126;load_layer();break;
		}
		else
		{
			thislayer.setAttribute("visibility", "visible")
		}
}


function inithier() 
{
//	SVGDoc=evt.getTarget().getOwnerDocument();
	for (i=0;i<cat_names.length;i++)
	{
		add_category(i)
		catStatus[i] = false;
	}
//	alert(maxWidth)
}

function add_category(num_category) 
{
// create category
	yCategory[num_category] = ((catFsize+catVertGap)*num_category)+yoffset
	navi = SVGDoc.getElementById("navi");
	newcateg = SVGDoc.createElement("g")
	newcateg.setAttribute("id","categ"+num_category)
	newcateg.setAttribute("transform","translate("+xoffset+","+yCategory[num_category]+")")
	navi.appendChild(newcateg)

aa = cat_names.length
if(num_category==(aa-1)) {
	hierheight = yCategory[num_category]+(catFsize+catVertGap)+10
	hierrect = SVGDoc.getElementById("hier_rect")
	hierrect.setAttribute("height",hierheight)
	currentNaviHeight = hierheight + 100
}

// create text entry (category title)	
	triangle = SVGDoc.createElement("path")
	triangle.setAttribute("d","M0 "+(catVertGap+4)+" 5 "+(catFsize+catVertGap-1)+" 10 "+(catVertGap+4)+"z")
	triangle.setAttribute("style","stroke:yellow;fill:yellow");
	newcateg.appendChild(triangle)

	categText = SVGDoc.createElement("text")
	categText.setAttribute("x",15)
	categText.setAttribute("y",catFsize+catVertGap)
	categText.setAttribute("style","text-anchor:left;font-size:"+catFsize+";font-family:Arial;fill:black;font-weight:bold")
	newcateg.appendChild(categText)
	t=SVGDoc.createTextNode(cat_names[num_category]);
	categText.appendChild(t);
	catWidth = categText.getComputedTextLength();
	if(catWidth > maxWidth) maxWidth = catWidth

	a=SVGDoc.createElement('a');
	a.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href","");
	newcateg.appendChild(a);


// create covering rectangle, for toggling	
	r = SVGDoc.createElement("rect")	
	r.setAttribute("x",0)
	r.setAttribute("y",catVertGap+layVertGap)
	r.setAttribute("width",catWidth)
	r.setAttribute("height",catFsize)
	r.setAttribute("onclick","toggleCategory(evt,"+num_category+")")
	r.setAttribute("style","stroke:none;fill:white;fill-opacity:0")
	a.appendChild(r)
//	newcateg.appendChild(r)


// add container for layers which are children of the category
	categ_container = SVGDoc.createElement("g")
	categ_container.setAttribute("id","cc"+num_category)
	categ_container.setAttribute("style","visibility:hidden")
	categ_container.setAttribute("transform","translate("+15+","+(catFsize+catVertGap+layVertGap)+")")
	newcateg.appendChild(categ_container)
	
// add layers which are children of the category
//	layerchk[num_category] = new Array()
	for (j=0;j<lay_names[num_category].length;j++)
	{
		add_layer(categ_container,num_category,j)
//		layerchk[num_category][j] = false
	}
	yCatsize[num_category] = (layFsize+layVertGap)*lay_names[num_category].length
}

function add_layer(container,num_cat,num_lay) 
{

	lay_container = SVGDoc.createElement("g")
	
//	lay_container.setAttribute("id","lay"+num_cat+"_"+num_lay)
	layerID=grset[num_cat][num_lay]
	lay_container.setAttribute("id",grtype[num_cat]+layerID+"_t")
	
	lay_container.setAttribute("transform","translate("+0+","+num_lay*(layFsize+layVertGap)+")")
	container.appendChild(lay_container)
// first rectangle
	rect1 = SVGDoc.createElement("rect")	
	rect1.setAttribute("x",0)
	rect1.setAttribute("y",0)
	rect1.setAttribute("width",layFsize)
	rect1.setAttribute("height",layFsize)
	rect1.setAttribute("style","stroke:black;fill:white")
	lay_container.appendChild(rect1)
//text
	lText = SVGDoc.createElement("text")
	lText.setAttribute("x",layFsize+layVertGap)
	lText.setAttribute("y",10)
	lText.setAttribute("style","text-anchor:left;font-size:"+layFsize+";font-family:Arial;fill:black")
	lay_container.appendChild(lText)
	t=SVGDoc.createTextNode(lay_names[num_cat][num_lay]);
	lText.appendChild(t);
	layWidth = lText.getComputedTextLength();
	if(layWidth > maxWidth) maxWidth = layWidth


//checkmark path container
	g=SVGDoc.createElement("g")
	g.setAttribute("id",grtype[num_cat]+layerID+"_cmark")
	lay_container.appendChild(g)


//rect2: something to click on
	rect2 = SVGDoc.createElement("rect")	
	rect2.setAttribute("x",0)
	rect2.setAttribute("y",0)
	rect2.setAttribute("onclick","toggleLayer(evt)")
	rect2.setAttribute("width",layFsize+layVertGap+layWidth)
	rect2.setAttribute("height",layFsize)
	rect2.setAttribute("style","stroke:none;fill:white;fill-opacity:0")
	lay_container.appendChild(rect2)
}
